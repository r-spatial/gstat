/* automatically generated from makefile: make version */
#define VERSION    "2.5.2 (30 April 2012)"
#define TARGET     "x86_64"
#define LASTMOD    "Mon Apr 30 22:32:10 CEST 2012"
