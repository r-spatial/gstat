#ifndef UI_H /* avoid multiple inclusion */
# define UI_H
int start_ui(void);
#endif
