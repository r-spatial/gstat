/* automatically generated from makefile: make version */
#define VERSION    "2.5.2 (02 May 2011)"
#define TARGET     "i686"
#define LASTMOD    "Mon May  2 18:17:33 CEST 2011"
