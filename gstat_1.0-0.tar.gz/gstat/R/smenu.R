# $Id: smenu.q,v 1.21 2006-10-31 13:25:15 edzer Exp $

