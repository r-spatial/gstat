# $Id: print.variogram.q,v 1.3 2006-02-10 19:01:07 edzer Exp $

"print.gstatVariogram" <-
function(x, ...)
{
	print(data.frame(x), ...)
}
